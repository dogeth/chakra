$(document).ready(function() {
	$('.container').show('slow');
});